const CACHE = 'gastos-v16';
const ASSETS = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png', './img/bg-painel.svg', './img/bg-metas.svg', './img/bg-notas.svg', './img/bg-tabela.svg', './img/bg-categorias.svg', './img/bg-cofre.svg', './img/bg-perfil.svg', './img/logo-G.svg'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== CACHE).map(x => caches.delete(x)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  const font = u.hostname === 'fonts.googleapis.com' || u.hostname === 'fonts.gstatic.com';
  if (u.origin !== location.origin && !font) return;
  if (r.mode === 'navigate') {
    // abre na hora com a cópia guardada; atualiza em segundo plano (sem esperar a rede)
    const net = fetch(r).then(res => {
      if (res && res.ok) { const cp = res.clone(); caches.open(CACHE).then(c => c.put('./index.html', cp)); }
      return res;
    }).catch(() => null);
    e.waitUntil(net);
    e.respondWith(caches.match('./index.html').then(hit => hit || net.then(res => res || caches.match('./index.html'))));
    return;
  }
  const net = fetch(r).then(res => {
    if (res && (res.ok || res.type === 'opaque')) {
      const cp = res.clone();
      caches.open(CACHE).then(c => c.put(r, cp));
    }
    return res;
  }).catch(() => null);
  e.waitUntil(net);
  e.respondWith(caches.match(r).then(hit => hit || net.then(res => res || Response.error())));
});
